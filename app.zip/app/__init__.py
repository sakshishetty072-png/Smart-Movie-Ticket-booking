"""
Movie Magic - Smart Movie Ticket Booking System
Flask Application Factory
"""

from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
import os

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'moviemagic-secret-key-2024')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///moviemagic.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # AWS Configuration
    app.config['AWS_REGION'] = os.environ.get('AWS_REGION', 'us-east-1')
    app.config['AWS_ACCESS_KEY_ID'] = os.environ.get('AWS_ACCESS_KEY_ID', '')
    app.config['AWS_SECRET_ACCESS_KEY'] = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    app.config['DYNAMODB_TABLE_USERS'] = os.environ.get('DYNAMODB_TABLE_USERS', 'MovieMagicUsers')
    app.config['DYNAMODB_TABLE_MOVIES'] = os.environ.get('DYNAMODB_TABLE_MOVIES', 'MovieMagicMovies')
    app.config['DYNAMODB_TABLE_BOOKINGS'] = os.environ.get('DYNAMODB_TABLE_BOOKINGS', 'MovieMagicBookings')
    app.config['SNS_TOPIC_ARN'] = os.environ.get('SNS_TOPIC_ARN', '')
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    
    # User loader
    @login_manager.user_loader
    def load_user(user_id):
        from app.models import User
        return User.query.get(int(user_id))
    
    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.booking import booking_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(booking_bp)
    
    # Create database tables
    with app.app_context():
        db.create_all()
    
    return app

