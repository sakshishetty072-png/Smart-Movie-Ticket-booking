"""
AWS DynamoDB Service for Movie Magic
Handles all database operations with AWS DynamoDB
"""

import boto3
from botocore.exceptions import ClientError
import json
import os

class DynamoDBService:
    """Service class for DynamoDB operations"""
    
    def __init__(self, app=None):
        self.dynamodb = None
        self.users_table = None
        self.movies_table = None
        self.bookings_table = None
        self.region = 'us-east-1'
        
        if app:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize DynamoDB connection with app config"""
        self.region = app.config.get('AWS_REGION', 'us-east-1')
        aws_access_key_id = app.config.get('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = app.config.get('AWS_SECRET_ACCESS_KEY')
        
        # Create DynamoDB resource
        if aws_access_key_id and aws_secret_access_key:
            self.dynamodb = boto3.resource(
                'dynamodb',
                region_name=self.region,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key
            )
        else:
            self.dynamodb = boto3.resource('dynamodb', region_name=self.region)
        
        # Get table names from config
        users_table_name = app.config.get('DYNAMODB_TABLE_USERS', 'MovieMagicUsers')
        movies_table_name = app.config.get('DYNAMODB_TABLE_MOVIES', 'MovieMagicMovies')
        bookings_table_name = app.config.get('DYNAMODB_TABLE_BOOKINGS', 'MovieMagicBookings')
        
        # Initialize tables
        try:
            self.users_table = self.dynamodb.Table(users_table_name)
            self.movies_table = self.dynamodb.Table(movies_table_name)
            self.bookings_table = self.dynamodb.Table(bookings_table_name)
        except Exception as e:
            print(f"Error initializing DynamoDB tables: {e}")
    
    # ==================== USER OPERATIONS ====================
    
    def create_user(self, user_data):
        """Create a new user in DynamoDB"""
        try:
            item = {
                'UserID': user_data.get('username'),
                'Email': user_data.get('email'),
                'FullName': user_data.get('full_name', ''),
                'Phone': user_data.get('phone', ''),
                'PasswordHash': user_data.get('password_hash'),
                'CreatedAt': user_data.get('created_at', '')
            }
            self.users_table.put_item(Item=item)
            return True
        except ClientError as e:
            print(f"Error creating user: {e}")
            return False
    
    def get_user(self, username):
        """Get user by username"""
        try:
            response = self.users_table.get_item(Key={'UserID': username})
            return response.get('Item')
        except ClientError as e:
            print(f"Error getting user: {e}")
            return None
    
    def update_user(self, username, update_data):
        """Update user information"""
        try:
            update_expression = 'SET '
            expression_values = {}
            expression_names = {}
            
            for key, value in update_data.items():
                update_expression += f'#{key} = :{key}, '
                expression_values[f':{key}'] = value
                expression_names[f'#{key}'] = key
            
            update_expression = update_expression.rstrip(', ')
            
            self.users_table.update_item(
                Key={'UserID': username},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_values,
                ExpressionAttributeNames=expression_names
            )
            return True
        except ClientError as e:
            print(f"Error updating user: {e}")
            return False
    
    # ==================== MOVIE OPERATIONS ====================
    
    def create_movie(self, movie_data):
        """Create a new movie in DynamoDB"""
        try:
            item = {
                'MovieID': movie_data.get('movie_id'),
                'Title': movie_data.get('title'),
                'Description': movie_data.get('description', ''),
                'Genre': movie_data.get('genre', ''),
                'Duration': movie_data.get('duration', 0),
                'Rating': movie_data.get('rating', 0.0),
                'PosterURL': movie_data.get('poster_url', ''),
                'ReleaseDate': movie_data.get('release_date', ''),
                'Location': movie_data.get('location', '')
            }
            self.movies_table.put_item(Item=item)
            return True
        except ClientError as e:
            print(f"Error creating movie: {e}")
            return False
    
    def get_all_movies(self, location=None):
        """Get all movies, optionally filtered by location"""
        try:
            if location:
                # Use scan with filter for location
                response = self.movies_table.scan(
                    FilterExpression='#loc = :loc',
                    ExpressionAttributeNames={'#loc': 'Location'},
                    ExpressionAttributeValues={':loc': location}
                )
            else:
                response = self.movies_table.scan()
            
            return response.get('Items', [])
        except ClientError as e:
            print(f"Error getting movies: {e}")
            return []
    
    def get_movie(self, movie_id):
        """Get movie by ID"""
        try:
            response = self.movies_table.get_item(Key={'MovieID': movie_id})
            return response.get('Item')
        except ClientError as e:
            print(f"Error getting movie: {e}")
            return None
    
    def search_movies(self, query, location=None):
        """Search movies by title or genre"""
        try:
            # Get all movies and filter
            movies = self.get_all_movies(location)
            query_lower = query.lower()
            
            results = []
            for movie in movies:
                if (query_lower in movie.get('Title', '').lower() or 
                    query_lower in movie.get('Genre', '').lower()):
                    results.append(movie)
            
            return results
        except Exception as e:
            print(f"Error searching movies: {e}")
            return []
    
    def update_movie_seats(self, movie_id, show_time, available_seats):
        """Update available seats for a movie show"""
        try:
            # This would require a more complex schema with showtimes
            # Simplified for now
            return True
        except Exception as e:
            print(f"Error updating seats: {e}")
            return False
    
    # ==================== BOOKING OPERATIONS ====================
    
    def create_booking(self, booking_data):
        """Create a new booking in DynamoDB"""
        try:
            item = {
                'BookingID': booking_data.get('booking_id'),
                'UserID': booking_data.get('user_id'),
                'MovieID': booking_data.get('movie_id'),
                'MovieTitle': booking_data.get('movie_title'),
                'ShowDate': booking_data.get('show_date'),
                'ShowTime': booking_data.get('show_time'),
                'SeatsBooked': booking_data.get('seats_booked'),
                'SeatNumbers': booking_data.get('seat_numbers'),
                'TotalPrice': booking_data.get('total_price'),
                'Venue': booking_data.get('venue'),
                'BookingStatus': booking_data.get('booking_status', 'confirmed'),
                'CreatedAt': booking_data.get('created_at', '')
            }
            self.bookings_table.put_item(Item=item)
            return True
        except ClientError as e:
            print(f"Error creating booking: {e}")
            return False
    
    def get_booking(self, booking_id):
        """Get booking by ID"""
        try:
            response = self.bookings_table.get_item(Key={'BookingID': booking_id})
            return response.get('Item')
        except ClientError as e:
            print(f"Error getting booking: {e}")
            return None
    
    def get_user_bookings(self, user_id):
        """Get all bookings for a user"""
        try:
            response = self.bookings_table.scan(
                FilterExpression='UserID = :uid',
                ExpressionAttributeValues={':uid': user_id}
            )
            return response.get('Items', [])
        except ClientError as e:
            print(f"Error getting user bookings: {e}")
            return []
    
    def update_booking_status(self, booking_id, status):
        """Update booking status"""
        try:
            self.bookings_table.update_item(
                Key={'BookingID': booking_id},
                UpdateExpression='SET BookingStatus = :status',
                ExpressionAttributeValues={':status': status}
            )
            return True
        except ClientError as e:
            print(f"Error updating booking status: {e}")
            return False


# Singleton instance
dynamodb_service = DynamoDBService()

