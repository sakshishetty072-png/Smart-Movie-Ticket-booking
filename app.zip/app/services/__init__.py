"""
Services package for Movie Magic
"""

from app.services.dynamodb_service import DynamoDBService, dynamodb_service
from app.services.sns_service import SNSService, sns_service

__all__ = ['DynamoDBService', 'dynamodb_service', 'SNSService', 'sns_service']

