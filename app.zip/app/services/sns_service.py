"""
AWS SNS Service for Movie Magic
Handles all notification operations with AWS SNS
"""

import boto3
from botocore.exceptions import ClientError
import json
import os

class SNSService:
    """Service class for SNS notification operations"""
    
    def __init__(self, app=None):
        self.sns_client = None
        self.topic_arn = None
        self.region = 'us-east-1'
        
        if app:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize SNS connection with app config"""
        self.region = app.config.get('AWS_REGION', 'us-east-1')
        aws_access_key_id = app.config.get('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = app.config.get('AWS_SECRET_ACCESS_KEY')
        self.topic_arn = app.config.get('SNS_TOPIC_ARN')
        
        # Create SNS client
        if aws_access_key_id and aws_secret_access_key:
            self.sns_client = boto3.client(
                'sns',
                region_name=self.region,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key
            )
        else:
            self.sns_client = boto3.client('sns', region_name=self.region)
    
    def publish_message(self, subject, message, phone_number=None, email=None):
        """
        Publish a message to SNS topic or directly to a subscriber
        
        Args:
            subject: Message subject
            message: Message body
            phone_number: Optional phone number for SMS
            email: Optional email for notification
        
        Returns:
            dict: Response from SNS or None on error
        """
        try:
            if phone_number:
                # Send SMS
                response = self.sns_client.publish(
                    PhoneNumber=phone_number,
                    Message=message,
                    Subject=subject
                )
                return response
            elif self.topic_arn:
                # Publish to topic
                message_json = {
                    'default': message,
                    'email': self._create_email_message(subject, message)
                }
                response = self.sns_client.publish(
                    TopicArn=self.topic_arn,
                    Subject=subject,
                    Message=json.dumps(message_json),
                    MessageStructure='json'
                )
                return response
            else:
                print("No topic ARN configured")
                return None
                
        except ClientError as e:
            print(f"Error publishing message: {e}")
            return None
    
    def _create_email_message(self, subject, message):
        """Create formatted email message"""
        return f"""
        <html>
        <head></head>
        <body>
            <h2>{subject}</h2>
            <p>{message}</p>
            <p style="margin-top: 20px; color: #666;">
                Thank you for choosing Movie Magic!<br>
                For any queries, contact our support team.
            </p>
        </body>
        </html>
        """
    
    def send_booking_confirmation(self, booking_details, user_email=None, phone_number=None):
        """
        Send booking confirmation notification
        
        Args:
            booking_details: Dictionary containing booking information
            user_email: User's email address
            phone_number: User's phone number
        
        Returns:
            bool: True if notification sent successfully
        """
        try:
            # Format the message
            subject = "🎬 Movie Magic - Booking Confirmation"
            
            message = f"""
            Dear {booking_details.get('user_name', 'Customer')},

            Thank you for booking with Movie Magic!

            BOOKING DETAILS:
            ----------------
            Booking ID: {booking_details.get('booking_id')}
            Movie: {booking_details.get('movie_title')}
            Date: {booking_details.get('show_date')}
            Time: {booking_details.get('show_time')}
            Venue: {booking_details.get('venue')}
            Seats Booked: {booking_details.get('seats_booked')}
            Seat Numbers: {booking_details.get('seat_numbers')}
            Total Price: ₹{booking_details.get('total_price')}

            Please arrive at the venue at least 30 minutes before the show.
            Present your booking ID at the counter to collect your tickets.

            Enjoy your movie!

            Best regards,
            Movie Magic Team
            """
            
            # Publish to SNS
            if phone_number:
                self.publish_message(subject, message, phone_number=phone_number)
            
            if self.topic_arn:
                self.publish_message(subject, message)
            
            return True
            
        except Exception as e:
            print(f"Error sending booking confirmation: {e}")
            return False
    
    def send_registration_welcome(self, user_name, user_email):
        """Send welcome message to new users"""
        try:
            subject = "Welcome to Movie Magic!"
            message = f"""
            Dear {user_name},

            Welcome to Movie Magic - Your Smart Movie Ticket Booking System!

            We're excited to have you on board. With Movie Magic, you can:
            • Browse latest movies and events
            • Book tickets in real-time
            • Get instant booking confirmations
            • Track your booking history

            Start exploring movies near you!

            Best regards,
            Movie Magic Team
            """
            
            if self.topic_arn:
                self.publish_message(subject, message)
            
            return True
            
        except Exception as e:
            print(f"Error sending welcome message: {e}")
            return False
    
    def subscribe_email_to_topic(self, email):
        """Subscribe an email address to the SNS topic"""
        try:
            response = self.sns_client.subscribe(
                TopicArn=self.topic_arn,
                Protocol='email',
                Endpoint=email
            )
            return response
        except ClientError as e:
            print(f"Error subscribing email: {e}")
            return None


# Singleton instance
sns_service = SNSService()

