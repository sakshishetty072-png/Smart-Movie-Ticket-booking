"""
Database Models for Movie Magic
Using SQLAlchemy for local development and DynamoDB for production
"""

from app import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

class User(UserMixin, db.Model):
    """User model for authentication and profile management"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    bookings = db.relationship('Booking', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'phone': self.phone,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Movie(db.Model):
    """Movie model for storing movie information"""
    __tablename__ = 'movies'
    
    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.String(50), unique=True, nullable=False)  # DynamoDB compatible ID
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    genre = db.Column(db.String(50))
    duration = db.Column(db.Integer)  # in minutes
    rating = db.Column(db.Float)  # IMDb rating
    poster_url = db.Column(db.String(500))
    release_date = db.Column(db.Date)
    location = db.Column(db.String(100))
    shows = db.relationship('Show', backref='movie', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'movie_id': self.movie_id,
            'title': self.title,
            'description': self.description,
            'genre': self.genre,
            'duration': self.duration,
            'rating': self.rating,
            'poster_url': self.poster_url,
            'release_date': self.release_date.isoformat() if self.release_date else None,
            'location': self.location
        }

class Show(db.Model):
    """Show model for movie showtimes"""
    __tablename__ = 'shows'
    
    id = db.Column(db.Integer, primary_key=True)
    show_id = db.Column(db.String(50), unique=True, nullable=False)
    movie_id = db.Column(db.Integer, db.ForeignKey('movies.id'), nullable=False)
    show_date = db.Column(db.Date, nullable=False)
    show_time = db.Column(db.Time, nullable=False)
    venue = db.Column(db.String(100))
    total_seats = db.Column(db.Integer, default=100)
    available_seats = db.Column(db.Integer, default=100)
    price = db.Column(db.Float, default=250.0)
    bookings = db.relationship('Booking', backref='show', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'show_id': self.show_id,
            'movie_id': self.movie_id,
            'show_date': self.show_date.isoformat() if self.show_date else None,
            'show_time': self.show_time.strftime('%H:%M') if self.show_time else None,
            'venue': self.venue,
            'total_seats': self.total_seats,
            'available_seats': self.available_seats,
            'price': self.price
        }

class Booking(db.Model):
    """Booking model for ticket reservations"""
    __tablename__ = 'bookings'
    
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.String(50), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    show_id = db.Column(db.Integer, db.ForeignKey('shows.id'), nullable=False)
    seats_booked = db.Column(db.Integer, nullable=False)
    seat_numbers = db.Column(db.String(200))  # JSON string of seat numbers
    total_price = db.Column(db.Float, nullable=False)
    booking_status = db.Column(db.String(20), default='confirmed')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'booking_id': self.booking_id,
            'user_id': self.user_id,
            'show_id': self.show_id,
            'seats_booked': self.seats_booked,
            'seat_numbers': self.seat_numbers,
            'total_price': self.total_price,
            'booking_status': self.booking_status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

