"""
Main Routes for Movie Magic
Handles home, dashboard, movie listings, and search
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from app import db
from app.models import Movie, Show, Booking
from datetime import datetime, date, timedelta
import uuid

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    """Home page route"""
    # Get featured movies (recent releases with good ratings)
    featured_movies = Movie.query.filter(
        Movie.release_date >= date.today() - timedelta(days=30)
    ).order_by(Movie.rating.desc()).limit(6).all()
    
    # Get all locations for filter
    locations = db.session.query(Movie.location).distinct().all()
    locations = [loc[0] for loc in locations if loc[0]]
    
    return render_template('main/home.html', 
                         featured_movies=featured_movies,
                         locations=locations)

@main_bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard with booking history"""
    user_bookings = Booking.query.filter_by(user_id=current_user.id).order_by(
        Booking.created_at.desc()
    ).all()
    
    # Calculate stats
    total_bookings = len(user_bookings)
    total_spent = sum(booking.total_price for booking in user_bookings)
    
    return render_template('main/dashboard.html',
                         bookings=user_bookings,
                         total_bookings=total_bookings,
                         total_spent=total_spent)

@main_bp.route('/movies')
def movies():
    """Movie listing page with filters"""
    location = request.args.get('location')
    genre = request.args.get('genre')
    search_query = request.args.get('q')
    
    query = Movie.query
    
    # Apply filters
    if location:
        query = query.filter(Movie.location == location)
    if genre:
        query = query.filter(Movie.genre == genre)
    if search_query:
        query = query.filter(Movie.title.ilike(f'%{search_query}%'))
    
    movies = query.order_by(Movie.release_date.desc()).all()
    
    # Get unique genres and locations for filter options
    genres = db.session.query(Movie.genre).distinct().all()
    genres = [g[0] for g in genres if g[0]]
    locations = db.session.query(Movie.location).distinct().all()
    locations = [loc[0] for loc in locations if loc[0]]
    
    return render_template('main/movies.html',
                         movies=movies,
                         genres=genres,
                         locations=locations,
                         selected_location=location,
                         selected_genre=genre,
                         search_query=search_query)

@main_bp.route('/movie/<int:movie_id>')
def movie_detail(movie_id):
    """Movie detail page with showtimes"""
    movie = Movie.query.get_or_404(movie_id)
    
    # Get upcoming shows for this movie
    shows = Show.query.filter(
        Show.movie_id == movie_id,
        Show.show_date >= date.today()
    ).order_by(Show.show_date, Show.show_time).all()
    
    # Group shows by date
    shows_by_date = {}
    for show in shows:
        show_date_str = show.show_date.strftime('%Y-%m-%d')
        if show_date_str not in shows_by_date:
            shows_by_date[show_date_str] = []
        shows_by_date[show_date_str].append(show)
    
    return render_template('main/movie_detail.html',
                         movie=movie,
                         shows=shows,
                         shows_by_date=shows_by_date)

@main_bp.route('/search')
def search():
    """Global search functionality"""
    query = request.args.get('q', '')
    
    if not query:
        return redirect(url_for('main.movies'))
    
    # Search movies by title or description
    movies = Movie.query.filter(
        (Movie.title.ilike(f'%{query}%')) |
        (Movie.description.ilike(f'%{query}%')) |
        (Movie.genre.ilike(f'%{query}%'))
    ).all()
    
    return render_template('main/search.html',
                         query=query,
                         movies=movies)

@main_bp.route('/about')
def about():
    """About page"""
    return render_template('main/about.html')

@main_bp.route('/contact')
def contact():
    """Contact page"""
    return render_template('main/contact.html')

# Admin routes (simplified)
@main_bp.route('/admin')
@login_required
def admin():
    """Admin dashboard (placeholder)"""
    if not current_user.username == 'admin':
        flash('Access denied.', 'danger')
        return redirect(url_for('main.home'))
    
    total_users = User.query.count()
    total_movies = Movie.query.count()
    total_bookings = Booking.query.count()
    total_revenue = db.session.query(db.func.sum(Booking.total_price)).scalar() or 0
    
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    
    return render_template('main/admin.html',
                         total_users=total_users,
                         total_movies=total_movies,
                         total_bookings=total_bookings,
                         total_revenue=total_revenue,
                         recent_bookings=recent_bookings)

@main_bp.route('/add-movie', methods=['GET', 'POST'])
@login_required
def add_movie():
    """Add new movie (admin route)"""
    if request.method == 'POST':
        movie = Movie(
            movie_id=str(uuid.uuid4())[:8],
            title=request.form.get('title'),
            description=request.form.get('description'),
            genre=request.form.get('genre'),
            duration=int(request.form.get('duration', 120)),
            rating=float(request.form.get('rating', 0.0)),
            poster_url=request.form.get('poster_url'),
            release_date=datetime.strptime(request.form.get('release_date'), '%Y-%m-%d').date(),
            location=request.form.get('location')
        )
        
        db.session.add(movie)
        db.session.commit()
        
        flash('Movie added successfully!', 'success')
        return redirect(url_for('main.movies'))
    
    return render_template('main/add_movie.html')

@main_bp.route('/add-show', methods=['GET', 'POST'])
@login_required
def add_show():
    """Add showtime for a movie (admin route)"""
    movies = Movie.query.all()
    
    if request.method == 'POST':
        movie_id = request.form.get('movie_id')
        show_date = datetime.strptime(request.form.get('show_date'), '%Y-%m-%d').date()
        show_time = datetime.strptime(request.form.get('show_time'), '%H:%M').time()
        venue = request.form.get('venue')
        total_seats = int(request.form.get('total_seats', 100))
        price = float(request.form.get('price', 250.0))
        
        show = Show(
            show_id=str(uuid.uuid4())[:8],
            movie_id=movie_id,
            show_date=show_date,
            show_time=show_time,
            venue=venue,
            total_seats=total_seats,
            available_seats=total_seats,
            price=price
        )
        
        db.session.add(show)
        db.session.commit()
        
        flash('Showtime added successfully!', 'success')
        return redirect(url_for('main.movies'))
    
    return render_template('main/add_show.html', movies=movies)

# Import User for admin route
from app.models import User

