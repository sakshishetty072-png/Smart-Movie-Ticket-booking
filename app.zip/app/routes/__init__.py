"""
Routes package for Movie Magic
"""

from app.routes.auth import auth_bp
from app.routes.main import main_bp
from app.routes.booking import booking_bp

__all__ = ['auth_bp', 'main_bp', 'booking_bp']

