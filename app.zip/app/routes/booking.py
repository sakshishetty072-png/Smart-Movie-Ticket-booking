"""
Booking Routes for Movie Magic
Handles seat selection, booking, and confirmation
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Movie, Show, Booking
from app.services.sns_service import sns_service
from datetime import datetime, date
import uuid
import json

booking_bp = Blueprint('booking', __name__, url_prefix='/booking')

@booking_bp.route('/select-seats/<int:show_id>', methods=['GET', 'POST'])
@login_required
def select_seats(show_id):
    """Seat selection page"""
    show = Show.query.get_or_404(show_id)
    movie = Movie.query.get_or_404(show.movie_id)
    
    if request.method == 'POST':
        selected_seats = request.form.getlist('seats')
        
        if not selected_seats:
            flash('Please select at least one seat.', 'danger')
            return redirect(url_for('booking.select_seats', show_id=show_id))
        
        # Calculate total price
        total_price = show.price * len(selected_seats)
        
        # Store booking info in session
        return redirect(url_for('booking.confirm_booking', 
                              show_id=show_id, 
                              seats=','.join(selected_seats)))
    
    # Generate seat layout (10 rows x 10 seats)
    rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
    seats_per_row = 10
    
    # Get already booked seats for this show
    existing_booking = Booking.query.filter_by(show_id=show_id).first()
    booked_seats = []
    if existing_booking and existing_booking.seat_numbers:
        booked_seats = existing_booking.seat_numbers.split(',')
    
    return render_template('booking/select_seats.html',
                         show=show,
                         movie=movie,
                         rows=rows,
                         seats_per_row=seats_per_row,
                         booked_seats=booked_seats)

@booking_bp.route('/confirm-booking/<int:show_id>')
@login_required
def confirm_booking(show_id):
    """Booking confirmation page"""
    show = Show.query.get_or_404(show_id)
    movie = Movie.query.get_or_404(show.movie_id)
    
    seats = request.args.get('seats', '').split(',')
    seats = [s for s in seats if s]  # Filter empty strings
    
    if not seats:
        flash('No seats selected.', 'danger')
        return redirect(url_for('main.movies'))
    
    total_price = show.price * len(seats)
    
    return render_template('booking/confirm_booking.html',
                         show=show,
                         movie=movie,
                         seats=seats,
                         total_price=total_price)

@booking_bp.route('/process-booking', methods=['POST'])
@login_required
def process_booking():
    """Process the booking and create booking record"""
    show_id = request.form.get('show_id')
    seats = request.form.get('seats', '').split(',')
    seats = [s for s in seats if s]
    
    if not show_id or not seats:
        flash('Invalid booking data.', 'danger')
        return redirect(url_for('main.movies'))
    
    show = Show.query.get_or_404(show_id)
    
    # Check seat availability
    if show.available_seats < len(seats):
        flash('Selected seats are no longer available.', 'danger')
        return redirect(url_for('booking.select_seats', show_id=show_id))
    
    # Generate booking ID
    booking_id = 'MM' + str(uuid.uuid4())[:8].upper()
    
    # Calculate total price
    total_price = show.price * len(seats)
    
    # Create booking record
    booking = Booking(
        booking_id=booking_id,
        user_id=current_user.id,
        show_id=show_id,
        seats_booked=len(seats),
        seat_numbers=','.join(seats),
        total_price=total_price,
        booking_status='confirmed',
        created_at=datetime.utcnow()
    )
    
    # Update available seats
    show.available_seats -= len(seats)
    
    db.session.add(booking)
    db.session.commit()
    
    # Send SNS notification
    try:
        booking_details = {
            'booking_id': booking_id,
            'user_name': current_user.full_name or current_user.username,
            'movie_title': show.movie.title,
            'show_date': show.show_date.strftime('%Y-%m-%d'),
            'show_time': show.show_time.strftime('%H:%M'),
            'venue': show.venue,
            'seats_booked': len(seats),
            'seat_numbers': ','.join(seats),
            'total_price': total_price
        }
        
        # Try to send notification via SNS
        if current_user.phone:
            sns_service.send_booking_confirmation(booking_details, phone_number=current_user.phone)
        
    except Exception as e:
        print(f"Error sending SNS notification: {e}")
        # Continue even if notification fails
    
    flash(f'Booking successful! Your booking ID is {booking_id}', 'success')
    return redirect(url_for('booking.booking_success', booking_id=booking_id))

@booking_bp.route('/booking-success/<booking_id>')
@login_required
def booking_success(booking_id):
    """Booking success page"""
    booking = Booking.query.filter_by(booking_id=booking_id).first_or_404()
    show = Show.query.get_or_404(booking.show_id)
    movie = Movie.query.get_or_404(show.movie_id)
    
    return render_template('booking/booking_success.html',
                         booking=booking,
                         show=show,
                         movie=movie)

@booking_bp.route('/my-bookings')
@login_required
def my_bookings():
    """User's booking history"""
    bookings = Booking.query.filter_by(user_id=current_user.id).order_by(
        Booking.created_at.desc()
    ).all()
    
    # Enrich booking data with movie and show info
    booking_data = []
    for booking in bookings:
        show = Show.query.get(booking.show_id)
        if show:
            movie = Movie.query.get(show.movie_id)
            booking_data.append({
                'booking': booking,
                'show': show,
                'movie': movie
            })
    
    return render_template('booking/my_bookings.html', bookings=booking_data)

@booking_bp.route('/booking-details/<booking_id>')
@login_required
def booking_details(booking_id):
    """Detailed view of a specific booking"""
    booking = Booking.query.filter_by(booking_id=booking_id).first_or_404()
    
    # Ensure user can only view their own bookings
    if booking.user_id != current_user.id:
        flash('Access denied.', 'danger')
        return redirect(url_for('booking.my_bookings'))
    
    show = Show.query.get_or_404(booking.show_id)
    movie = Movie.query.get_or_404(show.movie_id)
    
    return render_template('booking/booking_details.html',
                         booking=booking,
                         show=show,
                         movie=movie)

@booking_bp.route('/cancel-booking/<booking_id>', methods=['POST'])
@login_required
def cancel_booking(booking_id):
    """Cancel a booking"""
    booking = Booking.query.filter_by(booking_id=booking_id).first_or_404()
    
    # Ensure user can only cancel their own bookings
    if booking.user_id != current_user.id:
        flash('Access denied.', 'danger')
        return redirect(url_for('booking.my_bookings'))
    
    if booking.booking_status == 'cancelled':
        flash('Booking is already cancelled.', 'info')
        return redirect(url_for('booking.booking_details', booking_id=booking_id))
    
    # Update booking status
    booking.booking_status = 'cancelled'
    
    # Release seats
    show = Show.query.get(booking.show_id)
    show.available_seats += booking.seats_booked
    
    db.session.commit()
    
    flash('Booking cancelled successfully.', 'success')
    return redirect(url_for('booking.my_bookings'))

# API endpoints for AJAX operations
@booking_bp.route('/api/check-seats/<int:show_id>')
def api_check_seats(show_id):
    """API to check available seats for a show"""
    show = Show.query.get_or_404(show_id)
    
    # Get booked seats
    bookings = Booking.query.filter_by(show_id=show_id, booking_status='confirmed').all()
    booked_seats = []
    for booking in bookings:
        if booking.seat_numbers:
            booked_seats.extend(booking.seat_numbers.split(','))
    
    return jsonify({
        'available_seats': show.available_seats,
        'booked_seats': booked_seats,
        'total_seats': show.total_seats
    })

@booking_bp.route('/api/verify-seats', methods=['POST'])
@login_required
def api_verify_seats():
    """API to verify seat availability before booking"""
    data = request.get_json()
    show_id = data.get('show_id')
    selected_seats = data.get('seats', [])
    
    show = Show.query.get(show_id)
    if not show:
        return jsonify({'available': False, 'message': 'Show not found'})
    
    # Get already booked seats
    bookings = Booking.query.filter_by(show_id=show_id, booking_status='confirmed').all()
    booked_seats = []
    for booking in bookings:
        if booking.seat_numbers:
            booked_seats.extend(booking.seat_numbers.split(','))
    
    # Check if any selected seats are already booked
    unavailable = [seat for seat in selected_seats if seat in booked_seats]
    
    if unavailable:
        return jsonify({
            'available': False, 
            'message': f'Seats {", ".join(unavailable)} are no longer available.'
        })
    
    return jsonify({'available': True})

